<?php

namespace Location;

interface LocationType
{
    const ADMIN = 1;
    const USER = 2;
}
