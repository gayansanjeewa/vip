<?php

namespace Location;

use App\Http\Controllers\Controller;

class LocationController extends Controller
{

}
