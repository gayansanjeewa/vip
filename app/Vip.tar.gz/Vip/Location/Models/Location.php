<?php

namespace Location;

class Location
{

}
