<?php

namespace Location;

interface LocationInterface
{

}
