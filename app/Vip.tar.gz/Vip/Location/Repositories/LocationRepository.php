<?php

namespace Location;

class LocationRepository implements LocationInterface
{

}
